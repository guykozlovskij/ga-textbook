![GA](https://cloud.githubusercontent.com/assets/40461/8183776/469f976e-1432-11e5-8199-6ac91363302b.png)

# Redeploying MERN App to Heroku

* Work on your app as normal running  `yarn dev` or `yarn dev-fullstack` from the root of the back end.

* When you have finished all of your updates add and commit then `git push heroku main`

* You will also want to push your newly deployed app to your remote repo with `git push origin main` so that it stays up to date with the heroku version.
