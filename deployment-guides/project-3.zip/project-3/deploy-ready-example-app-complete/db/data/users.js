export default [
  {
    username: 'jack',
    email: 'jack@email',
    password: 'pass',
    passwordConfirmation: 'pass',
  },
  {
    username: 'noa',
    email: 'noa@email',
    password: 'pass',
    passwordConfirmation: 'pass',
  },
  {
    username: 'charlotte',
    email: 'charlotte@email',
    password: 'pass',
    passwordConfirmation: 'pass',
  }
]
